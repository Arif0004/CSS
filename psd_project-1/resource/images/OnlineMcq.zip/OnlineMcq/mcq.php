<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
       
    </style>
</head>
<body>
    
<?php 

error_reporting(0);

$q1=$_POST['q1'];
$q2=$_POST['q2'];
$q3=$_POST['q3'];

echo "<p>";
 echo "Your Result: "."<br>"."<br>";
if($q1=='Dhaka'){
    echo "1. Correct Answer."."<br>";
}else{
    echo "1. Incorrect Answer."." ". "and the correct answer is Dhaka"."<br>";
}
if($q2=='Islamabad'){
    echo "2. Correct Answer."."<br>";
}else{
    echo "2. Incorrect Answer."." "."and the correct answer is Islamabad"."<br>";
}
if($q3=='Delhi'){
    echo "3. Correct Answer."."<br>";
}else{
    echo "3. Incorrect Answer."." "."and the correct answer is Delhi"."<br>";
}
echo "</p>";

?>

</body>
</html>