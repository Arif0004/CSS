<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online MCQ System</title>
    <link href="images/fav.jpg" rel="icon">
    <link rel="stylesheet" href="css/style.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <style>
   
    </style>
</head>
<body>
    <section class="header">
        <div class="container">
            
                <div class="row">
                    <div class="col-md-12 text-center">
                    <div class="mcq-header">
                    <h1>Online MCQ System</h1>
                   </div>
                </div>
            
              </div>
          </div>
     </section>

<section class="mcq-part">
<div class="container">
<form action="mcq.php" method="post">
<div class="row">


  <div class="col-md-6 py-4">
    <div class="card shadow">
      <div class="card-body">

      <h5 class="card-title">1. What is the Capital Of Bangladesh?</h5>
      A. <input  type="radio" name="q1" value="Delhi" required>Delhi <br>
      B. <input type="radio" name="q1" value="Dhaka" required>Dhaka  <br>
      C. <input type="radio" name="q1" value="Islamabad" required>Islamabad <br>
      D. <input type="radio" name="q1" value="Tehran" required>Tehran <br> <br>
      </div>
    </div>
  </div>

  <div class="col-md-6 py-4">
    <div class="card shadow">
      <div class="card-body">
 
      <h5 class="card-title">2. What is the Capital of Pakistan?</h5>
      A. <input type="radio" name="q2" value="Dhaka" required> Dhaka <br>
     B. <input type="radio" name="q2" value="Delhi" required> Delhi <br>
     C. <input type="radio" name="q2" value="Tehran" required> Tehran <br>
     D. <input type="radio" name="q2" value="Islamabad" required> Islamabad <br> <br>
 
      </div>
    </div>
  </div>

  <div class="col-md-6 py-4">
    <div class="card shadow">
      <div class="card-body">
  
      <h5 class="card-title">3. What is the Capital of India?</h5>
      A. <input type="radio" name="q3" value="Delhi" required> Delhi <br>
     B. <input type="radio" name="q3" value="Dhaka" required> Dhaka <br>
     C. <input type="radio" name="q3" value="Tehran" required> Tehran <br>
     D. <input type="radio" name="q3" value="Islamabad" required> Islamabad <br><br>

      </div>
    </div>
  </div>
 
  

</div>
<input class="btn btn-secondary" type="submit" name="submit" value="Submit">
</form>
</div>
</section>

<!--
<section class="mcq-section">
<form action="mcq.php" method="post">
     <p >1. What is the Capital Of Bangladesh?</p>
     A. <input type="radio" name="q1" value="Delhi" required>Delhi <br>
     B. <input type="radio" name="q1" value="Dhaka" required>Dhaka  <br>
     C. <input type="radio" name="q1" value="Islamabad" required>Islamabad <br>
     D. <input type="radio" name="q1" value="Tehran" required>Tehran <br> <br>
     </form>
     <p>2. What is the Capital of Pakistan?</p>
     A. <input type="radio" name="q2" value="Dhaka" required> Dhaka <br>
     B. <input type="radio" name="q2" value="Delhi" required> Delhi <br>
     C. <input type="radio" name="q2" value="Tehran" required> Tehran <br>
     D. <input type="radio" name="q2" value="Islamabad" required> Islamabad <br> <br>
     <p>3. What is the Capital of India?</p>
     A. <input type="radio" name="q3" value="Delhi" required> Delhi <br>
     B. <input type="radio" name="q3" value="Dhaka" required> Dhaka <br>
     C. <input type="radio" name="q3" value="Tehran" required> Tehran <br>
     D. <input type="radio" name="q3" value="Islamabad" required> Islamabad <br><br>
     <input type="submit" name="submit" value="Submit">

</section>
-->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js" integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF" crossorigin="anonymous"></script>
</body>
</html>